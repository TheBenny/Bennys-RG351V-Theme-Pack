theme:          NES BOX Theme designed by Travis Wilson (Super Retropie and Retro Gaming)

facebook:		www.facebook.com/groups/superretropie

twitter:		www.twitter.com/superretropie

email:			superretropieretrogaming@gmail.com

version         1.8

------------------------------------------------------------------------------------------

License

This theme is being actively developed, a great deal of work has been put into the theme and art so please do not use the graphics I have created in other projects.

You are free to modify the theme for your personal use only - please do not share modified versions of this theme.

Commercial distribution is prohibited

------------------------------------------------------------------------------------------

Travis Wilson / Super Retropie and Retro Gaming / made this theme. 

This theme is not for use with any kind of loaded images. 

This theme is not for use with anything Supreme Retro Gaming related.

------------------------------------------------------------------------------------------

Supported Systems and Custom Collections

3do

3ds

aae

acclaim

advision

ags

amiga

amigacd32

amstradcpc

android

apple2

arcade

asteroids

astrocade

atari800

atari2600

atari5200

atari7800

atarijaguar

atarilynx

atarist

atomiswave

auto-allgames

auto-favorites

auto-lastplayed

batman

battletoads

bbcmicro

bomberman

bubblebobble

c64

capcom

castlevania

cdimono1

centipede

channelf

chromium

colecovision

contra

cps1

cps2

cps3

crashbandicoot

crvision

custom-collections

daphne

dataeast

defender

digdug

disney

donkeykong

doom

doubledragon

dreamcast

earthwormjim

electron

famicom

famicom-classic

famicom-hacks

fatalfury

fba

fba_libretro

fbn

fds

finalfantasy

finalfight

frogger

galaga

gameandwatch

gamegear

gamegear-hacks

gb

gb-hacks

gb-super

gba

gba-hacks

gbc

gbc-hacks

gc

genesis

genesis-hacks

ghoulsandghosts

hacks

hulk

ibm

indianajones

intellivision

irem

jamesbond

joust

kaneko

kirby

kodi

kof

konami

lego

macintosh

mame

mame-advmame

mame-libretro

mame-mame4all

mario

mariokart

marioparty

markiii

markiii-hacks

marvel

mastersystem

mega32x

megacd

megadrive

megadrive-hacks

megaduck

megaman

megamanx

mess

metalslug

metroid

midway

mortalkombat

msdos

msx

msx2

n64

n64dd

namco

naomi

nbajam

nds

needforspeed

neogeo-cd

neogeo

nes

nes-classic

nes-hacks

ngp

ngpc

ninjagaiden

odyssey2

openbor

oric

outrun

pacman

panasonic

pc

pce-cd

pcengine

pcfx

pico8

pokemini

pokemon

pokemon-hacks

ports

powerrangers

princeofpersia

ps2

psikyo

psp

pspminis

psx

psx-classic

pv1000

pv2000

rampage

residentevil

residualvm

retropie

roadrash

robocop

samcoupe

satellaview

saturn

sc-3000

scummvm

sega

sega32x

segacd

sfc

sfc-cd

sfc-classic

sfc-hacks

sg-1000

sgb

shinobi

simpsons

snes

snes-cd

snes-classic

snes-hacks

snk

sonic

sony

spaceinvaders

spiderman

splatterhouse

startrek

starwars

steam

strategus

streetfighter

sufami

supergrafx

supervision

taito

technos

tecmo

tectoy

tetris

tg-cd

tg16

ti99

tiger

tmnt

vector

vectrex

vhs

vic20

videopac

virtualboy

visco

vmnuon

wario

wii

wiiu

wiiware

wonderswan

wonderswancolor

wwf

x1

x68000

xmen

zelda

zmachine

zx81

zxspectrum

** there is a launching image folder with a launching.png inside to match the theme
